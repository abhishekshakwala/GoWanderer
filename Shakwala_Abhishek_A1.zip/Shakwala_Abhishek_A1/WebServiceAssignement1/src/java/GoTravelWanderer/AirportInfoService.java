/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GoTravelWanderer;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import net.webservicex.Airport;
import net.webservicex.AirportSoap;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author avs23
 */
public class AirportInfoService {

    public List<String> getAirportInfoByCountry(String country) throws ParserConfigurationException, SAXException, IOException{
        Airport a = new Airport();
        AirportSoap airportSoap = a.getAirportSoap();
        country = country.replaceAll("%20", " ");
        String getAirport = airportSoap.getAirportInformationByCountry(country);
        System.out.println("-----------PRINTING AIRPORT BY COUNTRY------------");
        //System.out.println(getAirport);
        
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance(); 
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        InputSource is = new InputSource();
        is.setCharacterStream(new StringReader(getAirport));
        Document doc = dBuilder.parse(is);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("Table");
        List<String> codeList = new ArrayList<String>();
        List<String> cityList = new ArrayList<String>();
        for (int temp = 0; temp < nList.getLength(); temp++){ 
            Node nNode = nList.item(temp); 
            if (nNode.getNodeType() == Node.ELEMENT_NODE){ 
                Element eElement = (Element) nNode;
                String code = eElement.getElementsByTagName("AirportCode").item(0).getTextContent();
                codeList.add(code);
                String cityName = eElement.getElementsByTagName("CityOrAirportName").item(0).getTextContent();
                cityList.add(cityName);
            }
        }
        Set<String> cl = new HashSet<>();
        cl.addAll(codeList);
        codeList.clear();
        codeList.addAll(cl);
        Set<String> city = new HashSet<>();
        city.addAll(cityList);
        cityList.clear();
        cityList.addAll(city);
        for(String airportCode : codeList){
            System.out.println(airportCode);
        }
        return codeList;
    }
}
