/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GoTravelWanderer;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import net.webservicex.Country;
import net.webservicex.CountrySoap;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author avs23
 */
public class CountriesService {

    public List<String> getCountry() throws ParserConfigurationException, SAXException, IOException {
        Country c = new Country();
        CountrySoap countrySoap = c.getCountrySoap();
        String getCountries = countrySoap.getCountries();
        System.out.println("-----------PRINTING COUNTRIES------------");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        InputSource is = new InputSource();
        is.setCharacterStream(new StringReader(getCountries));
        Document doc = dBuilder.parse(is);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("Table");
        List<String> countryList = new ArrayList<String>();
        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                String code = eElement.getElementsByTagName("Name").item(0).getTextContent();
                countryList.add(code);
            }
        }
        for(String country : countryList){
            System.out.println(country);
        }
        return countryList;
    }
}
