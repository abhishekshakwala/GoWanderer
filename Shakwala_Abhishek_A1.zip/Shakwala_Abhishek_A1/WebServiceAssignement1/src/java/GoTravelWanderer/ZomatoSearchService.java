/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GoTravelWanderer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Iterator;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author avs23
 */
public class ZomatoSearchService {

    public String getZomatoSearch(String query) throws MalformedURLException, ProtocolException, IOException, org.json.simple.parser.ParseException{
        System.out.println(query);
        query = query.replaceAll(" ", "%20");
        URL url = new URL("https://developers.zomato.com/api/v2.1/locations?query="+query);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.addRequestProperty("user-key", "617eaa4e39a385d5d689de47660bd663");
        connection.setRequestMethod("GET");
        connection.connect();
        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String str;
        StringBuffer stringBuffer = new StringBuffer();
        while((str = br.readLine()) != null){
            stringBuffer.append(str);
            stringBuffer.append("\n");
        }
        //System.out.println(stringBuffer.toString());
        str = stringBuffer.toString();
        JSONParser parser = new JSONParser();
        JSONObject obj= (JSONObject) parser.parse(str);
        JSONArray msg = (JSONArray) obj.get("location_suggestions");
        Iterator<?> iterator = msg.iterator();
        JSONObject a;
        Long entity_id = null;
        String entity_type = null;
        while(iterator.hasNext()){
            a = (JSONObject) iterator.next();
            entity_type = (String) a.get("entity_type");
            entity_id = (Long) a.get("entity_id");
        }
        ZomatoSearchService cs = new ZomatoSearchService();
        String restaurantDetails = cs.getZomatoLocationDetails(entity_id, entity_type, query);
        return restaurantDetails;
    }
    
    public String getZomatoLocationDetails(Long entity_id, String entity_type, String dest) throws MalformedURLException, IOException, org.json.simple.parser.ParseException{
        URL url = new URL("https://developers.zomato.com/api/v2.1/location_details?entity_id="+entity_id+"&entity_type="+entity_type);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.addRequestProperty("user-key", "617eaa4e39a385d5d689de47660bd663");
        connection.setRequestMethod("GET");
        connection.connect();
        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String str;
        StringBuffer stringBuffer = new StringBuffer();
        while((str = br.readLine()) != null){
            stringBuffer.append(str);
            stringBuffer.append("\n");
        }
        //System.out.println(stringBuffer.toString());
        str = stringBuffer.toString();
        JSONParser parser = new JSONParser();
        JSONObject obj= (JSONObject) parser.parse(str);
        JSONArray topCusines = (JSONArray) obj.get("top_cuisines");
        String cuisines = "";
        for(int i=0; i<topCusines.size(); i++){
            cuisines += (i != topCusines.size()-1) ? topCusines.get(i)+", " : topCusines.get(i);
        }
        System.out.println("Cuisines Served in "+dest+": "+cuisines);
        JSONArray msg = (JSONArray) obj.get("best_rated_restaurant");
        Iterator<?> iterator = msg.iterator();
        JSONObject a;
        System.out.println("--------FETCHING RESTAURANTS FOR YOU IN "+dest+":----------");
        while(iterator.hasNext()){
            a = (JSONObject) iterator.next();
            JSONObject subarray1 = (JSONObject) a.get("restaurant");
            System.out.println();
            System.out.println("Restaurant Name: "+subarray1.get("name"));
            System.out.println("Cuisines Served: "+subarray1.get("cuisines"));
            System.out.println("Cost for Two: "+subarray1.get("currency")+subarray1.get("average_cost_for_two"));
            JSONObject subarray2 = (JSONObject) subarray1.get("location");
            System.out.println("Address: "+subarray2.get("address"));
        }
        return str;
    }
}
