/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GoTravelWanderer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 *
 * @author avs23
 */
public class FlightSearchService {

    public String flightSearch(String origin, String destination, String dateValue, Boolean tripType, Boolean direct, int maxPrice) throws MalformedURLException, IOException {
        String param = "apikey=78gPp7zkTj5tdOE0HKLmSYf9GepFFE2L&origin=" + origin + "&destination=" + destination + "&departure_date=" + dateValue + "&one-way=" + tripType + "&direct=" + direct + "&max_price=" + maxPrice;
        URL url = new URL("https://api.sandbox.amadeus.com/v1.2/flights/extensive-search?" + param);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.connect();
        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String str;
        StringBuffer stringBuffer = new StringBuffer();
        while ((str = br.readLine()) != null) {
            stringBuffer.append(str);
            stringBuffer.append("\n");
        }
        System.out.println(stringBuffer.toString());
        str = stringBuffer.toString();
        return str;
    }
}
