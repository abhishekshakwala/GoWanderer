/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GoTravelWanderer;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author avs23
 */
@WebServlet(name = "query", urlPatterns = {"/query"})
public class query extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet query</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet query at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, MalformedURLException, ProtocolException {
        //processRequest(request, response);
        String serviceType = request.getParameter("servicetype");
        /*
        String user = "Service Type is: " + serviceType;
        response.setContentType("text/plain");
        response.getWriter().write(user);
         */
        if (serviceType.equals("country")) {
            CountriesService cs = new CountriesService();
            List<String> countries = null;
            try {
                countries = cs.getCountry();

            } catch (ParserConfigurationException ex) {
                Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
            }
            PrintWriter out = response.getWriter();
            response.setContentType("text/html");
            out.println("<select id='id1' onchange='getAirportCodeAjax();'>");
            out.println("<option>Select the Country</option>");
            for (String country : countries) {
                out.println("<option value=" + country.replaceAll(" ", "%20") + ">" + country + "</option>");
            }
            out.println("</select>");
            out.println("<br>");
            out.println("<br>");
        } else if (serviceType.equals("airport")) {
            String countrySelected = request.getParameter("countrySelected");
            AirportInfoService ais = new AirportInfoService();
            List<String> airport = null;
            try {
                airport = ais.getAirportInfoByCountry(countrySelected);
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
            }
            PrintWriter out = response.getWriter();
            response.setContentType("text/html");
            out.println("<select id='id2'>");
            out.println("<option>Select the Origin Airport Code</option>");
            for (String code : airport) {
                if(code.equals("JFK")){
                    code = "NYC";
                }
                out.println("<option value=" + code + ">" + code + "</option>");
            }
            out.println("</select>");
            out.println("<br>");
            out.println("<br>");
            out.println("<select id='id3' onload='getForm();'>");
            out.println("<option>Select the Destination Airport Code</option>");
            for (String code : airport) {
                if(code.equals("JFK")){
                    code = "NYC";
                }
                out.println("<option value=" + code + ">" + code + "</option>");
            }
            out.println("</select>");
            out.println("<br>");
            out.println("<br>");
        } else if (serviceType.equals("flightdetails")) {
            String origin = request.getParameter("origin");
            String destination = request.getParameter("destination");
            String dateValue = request.getParameter("departuredate");
            String trip = request.getParameter("triptype");
            Boolean triptype = Boolean.valueOf(trip);
            String directTrip = request.getParameter("direct");
            Boolean direct = Boolean.valueOf(directTrip);
            int price = Integer.parseInt(request.getParameter("maxprice"));
            FlightSearchService fss = new FlightSearchService();
            String details = fss.flightSearch(origin, destination, dateValue, triptype, direct, price);
            JSONParser parser = new JSONParser();
            JSONObject obj = null;
            try {
                obj = (JSONObject) parser.parse(details);
            } catch (ParseException ex) {
                Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
            }
            String currency = (String) obj.get("currency");
            JSONArray msg = (JSONArray) obj.get("results");
            Iterator<?> iterator = msg.iterator();
            JSONObject a;
            PrintWriter out = response.getWriter();
            response.setContentType("text/html");
            out.println("<h1><font color=\"black\">Here is the list of flights!!</font></h1>");
            out.println("<br>");
            out.println("<table id='responseTable1'>");
            out.println("<tr>");
            out.println("<th>");
            out.println("Origin");
            out.println("</th>");
            out.println("<th>");
            out.println("Destination");
            out.println("</th>");
            out.println("<th>");
            out.println("Departure Date");
            out.println("</th>");
            out.println("<th>");
            out.println("Return Date");
            out.println("</th>");
            out.println("<th>");
            out.println("Price");
            out.println("</th>");
            out.println("<th>");
            out.println("Airlines");
            out.println("</th>");
            out.println("</tr>");
            while (iterator.hasNext()) {
                a = (JSONObject) iterator.next();
                out.println("<tr>");
                out.println("<td>" + origin + "</td>");
                out.println("<td>" + a.get("destination") + "</td>");
                out.println("<td>" + a.get("departure_date") + "</td>");
                out.println("<td>" + a.get("return_date") + "</td>");
                out.println("<td>" + currency + a.get("price") + "</td>");
                out.println("<td>" + a.get("airline") + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");
            out.println("<br>");
            
            ZomatoSearchService zss = new ZomatoSearchService();
            String restaurantdetails = null;
            try {
                restaurantdetails = zss.getZomatoSearch(destination);
            } catch (ParseException ex) {
                Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
            }
            JSONParser zomatoParser = new JSONParser();
            JSONObject objZomato = null;
            try {
                objZomato = (JSONObject) zomatoParser.parse(restaurantdetails);
            } catch (ParseException ex) {
                Logger.getLogger(query.class.getName()).log(Level.SEVERE, null, ex);
            }
            JSONArray msgZomato = (JSONArray) objZomato.get("best_rated_restaurant");
            Iterator<?> iteratorZomato = msgZomato.iterator();
            JSONObject aZomato;
            PrintWriter outZomato = response.getWriter();
            response.setContentType("text/html");
            outZomato.println("<h1><font color=\"black\">Here is the list of restaurants in "+destination+"!!</font></h1>");
            outZomato.println("<br>");
            outZomato.println("<table id='responseTable2'>");
            outZomato.println("<tr>");
            outZomato.println("<th>");
            outZomato.println("Restaurant Name");
            outZomato.println("</th>");
            outZomato.println("<th>");
            outZomato.println("Cuisines Served");
            outZomato.println("</th>");
            outZomato.println("<th>");
            outZomato.println("Cost for Two");
            outZomato.println("</th>");
            outZomato.println("<th>");
            outZomato.println("Overall Ratings");
            outZomato.println("</th>");
            outZomato.println("<th>");
            outZomato.println("Address");
            outZomato.println("</th>");
            outZomato.println("</tr>");
            while (iteratorZomato.hasNext()) {
                aZomato = (JSONObject) iteratorZomato.next();
                JSONObject subarray1 = (JSONObject) aZomato.get("restaurant");
                outZomato.println("<tr>");
                outZomato.println("<td>" + subarray1.get("name") + "</td>");
                outZomato.println("<td>" + subarray1.get("cuisines") + "</td>");
                outZomato.println("<td>" + subarray1.get("currency")+subarray1.get("average_cost_for_two") + "</td>");
                JSONObject subarray2 = (JSONObject) subarray1.get("user_rating");
                outZomato.println("<td>" + subarray2.get("rating_text")+": "+subarray2.get("aggregate_rating") + "</td>");
                JSONObject subarray3 = (JSONObject) subarray1.get("location");
                outZomato.println("<td>" + subarray3.get("address") + "</td>");
                outZomato.println("</tr>");
            }
            outZomato.println("</table>");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
